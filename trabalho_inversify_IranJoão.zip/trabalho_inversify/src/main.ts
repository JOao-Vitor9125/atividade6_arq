import "reflect-metadata";
import dotenv from "dotenv";
import express, {Request, Response} from "express";
import {container} from "./container";
import { ReportServico } from "./dominio(REGRAS)/report.servico";
import {TYPES} from "./types";
import { TamanhoInvalidoRegistro } from "./dominio(REGRAS)/erros";

dotenv.config();

const app = express();
const port = process.env.APP_PORT || 3000;

app.get("/relatorio/:n", async (req: Request, res: Response): Promise<any> => {
    try {
        const n = parseInt(req.params.n);
        const email = req.query.email as string;

        if (!email) {
            return res.status(400).send("É obrigatorio o uso de Email na query string.");
        }

        const reportService = container.get<ReportServico>(TYPES.ReportService);
        await reportService.gerarEenviar(email, n);
        return res.status(200).send("Relario enviado!")
    } catch (error) {
        if (error instanceof TamanhoInvalidoRegistro) {
            return res.status(400).send(error.message);
        }
        console.error(error);
        return res.status(500).send("Erro interno no servidor");
    }
});

app.listen(port, () => {
    console.log(`Rodando servidor na porta ${port} em modo ${process.env.APP_ENV}`);
});