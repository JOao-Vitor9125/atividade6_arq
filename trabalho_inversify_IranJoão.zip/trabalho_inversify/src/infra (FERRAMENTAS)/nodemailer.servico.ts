import { injectable } from "inversify";
import { IMailer } from "../dominio(REGRAS)/interfaces";
import nodemailer from "nodemailer";

@injectable()
export class ServicoNodemailer implements IMailer {
    private transporter: nodemailer.Transporter;

    constructor() {
        this.initTransporter();
    }

    private async initTransporter(){
        const env = process.env.APP_ENV || 'dev';
        //teste com fake
        if (env === 'dev'){
            const ContaTeste = await nodemailer.createTestAccount();
            this.transporter = nodemailer.createTransport({
                host: "smtp.ethereal.email",
                port: 587,
                secure: false,
                auth: {
                    user:ContaTeste.user,
                    pass:ContaTeste.pass,
                },
            });
            console.log("Modo DEV: Testando Ethereal Mail");
        } else {
            this.transporter = nodemailer.createTransport({
                host: process.env.SMTP_HOST,
                port: Number(process.env.SMTP_PORT),
                auth: {
                    user: process.env.SMTP_USER,
                    pass: process.env.SMTP_PASS,
                },
            })
        }
    }

    async send(to:string, subject: string, body: string): Promise<void>{
        if (!this.transporter) await this.initTransporter();
    
        const info = await this.transporter.sendMail({
            from: '"Sistema" <sistema@empresa.com>',
            to,
            subject,
            text: body,
        });

        if (process.env.APP_ENV === 'dev') {
            console.log("URL: %s", nodemailer.getTestMessageUrl(info));
        }
    }
}