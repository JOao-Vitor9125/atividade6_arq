import {injectable} from "inversify";
import {ILogger} from "../dominio(REGRAS)/interfaces";
import winston from "winston";

@injectable()
export class WinstonLogger implements ILogger {
    private logger: winston.Logger;

    constructor(){
        const env= process.env.APP_ENV || 'dev';

        const transports = env === 'prod'
            ?[new winston.transports.File({ filename: 'app.log'})]
            :[new winston.transports.Console({format: winston.format.simple()})];

        this.logger = winston.createLogger({
            level: 'info',
            transports: transports
        });
    }

    info(msg: string): void {this.logger.info(msg);}
    warn(msg: string): void {this.logger.warn(msg);}
    error(msg: string): void{this.logger.error(msg);}
}