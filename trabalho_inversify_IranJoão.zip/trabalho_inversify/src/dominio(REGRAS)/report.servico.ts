import { injectable, inject } from "inversify";
import { faker} from "@faker-js/faker";
import { ILogger, IMailer} from "./interfaces";
import {TamanhoInvalidoRegistro} from "./erros";
import {TYPES } from "../types"
import { createEmitAndSemanticDiagnosticsBuilderProgram } from "typescript";

@injectable()
export class ReportServico {
    constructor(
        @inject(TYPES.Logger) private logger: ILogger,
        @inject(TYPES.Mailer ) private mailer: IMailer
    ) {}

    public async gerarEenviar(email: string, n:number): Promise<void> {
        if (n<1 || n>10){
            this.logger.error(`Tentativa de gerar relatorio falhou por nao possuir tamnho valido: ${n}`);
            throw new TamanhoInvalidoRegistro();
        }

        this.logger.info(`Iniciando geração de relatorio no email: ${email} com ${n} registros`);
    
        const data = [];
        for (let i=0; i < n; i++) {
            data.push({
                nome: faker.person.fullName(),
                cidade: faker.location.city()
            });
        }

        const reportBody = JSON.stringify(data, null, 2);

        await this.mailer.send(email, "Relatório de Dados", reportBody);
        this.logger.info("Relatorio enviado com sucesso.");
    }
}
